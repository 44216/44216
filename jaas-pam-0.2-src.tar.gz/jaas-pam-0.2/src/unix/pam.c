/*
  The native interface implementation of Pam.java
  
  Authors: Ortwin Gl�ck, Carsten Weisse
*/
#include <dlfcn.h>
#include <security/pam_appl.h>
#include <security/pam_misc.h>
#include "ch_odi_pam_Pam.h"

/*
 * Safe duplication of strings
 * http://www.kernel.org/pub/linux/libs/pam/Linux-PAM-html/pam_appl-5.html
 *
 * use pam macro x_strdup(s)
 */

/* DEFINE STATIC STRUCTURES AND VARIABLES SO THAT
   THEY ONLY HAVE SCOPE WITHIN THE METHODS AND FUNCTIONS OF
   THIS SOURCE FILE */

/*
 * hold handles to the pam shared libs
 * dlopen in JNI_OnLoad
 * and
 * dlclose in JNI_OnUnload
 */
static void* libpam;
static void* libpam_misc;

/*
 * is used as conversation appdata_ptr
 * http://www.kernel.org/pub/linux/libs/pam/Linux-PAM-html/pam_appl-3.html#ss3.2
 *
 * holds a JVM handle and a Pam.java object reference (pam handle)
 * makes pam conversation thread-safe
 */
static struct conv_param_t {
  JavaVM *vm;
  jobject pam;
};

static int conversation (int num_msg,
                  const struct pam_message **msg,
                  struct pam_response **resp,
                  void *appdata_ptr) {
  struct conv_param_t *appdata = (struct conv_param_t*) appdata_ptr;
  
  jint ret = PAM_CONV_ERR;
  //attach this thread to the VM
  JavaVM *vm = (*appdata).vm;
  jobject pam = (*appdata).pam;
  JNIEnv *env;
  (*vm)->AttachCurrentThread(vm, (void **)&env, NULL);   
  
  //convert message array
  // msg_ar = new PamMessage[num_msg];
  jclass msg_class = (*env)->FindClass(env, "ch/odi/pam/PamMessage"); if (msg_class == NULL) goto error;
  jobjectArray msg_ar = (*env)->NewObjectArray(env, num_msg, msg_class, NULL); if (msg_ar == NULL) goto error;
  jmethodID msg_ctorid = (*env)->GetMethodID(env, msg_class, "<init>", "(ILjava/lang/String;)V");  if (msg_ctorid == NULL) goto error;
  int i;
  for (i=0; i < num_msg; i++) {
      // msg_ar[i] = new PamMessage(msg[i].msg_style, msg[i].msg);
    jstring s = (*env)->NewStringUTF(env, msg[i]->msg);
    jobject omsg = (*env)->NewObject(env, msg_class, msg_ctorid, msg[i]->msg_style, s); if (omsg == NULL) goto error;
    (*env)->SetObjectArrayElement(env, msg_ar, i, omsg);
  }

  //create an empty response array
  jclass resp_class = (*env)->FindClass(env, "ch/odi/pam/PamResponse"); if (resp_class == NULL) goto error;
  jobjectArray resp_ar = (*env)->NewObjectArray(env, num_msg, resp_class, NULL); if (resp_ar == NULL) goto error;
  
  // hold a reference of PamResponse[] until callback is finished
  resp_ar = (*env)->NewGlobalRef(env, resp_ar);
  
  //invoke method
  jclass clazz = (*env)->GetObjectClass(env, pam); if (clazz == NULL) goto error;
  jmethodID pam_convid = (*env)->GetMethodID(env, clazz, "conversation", "([Lch/odi/pam/PamMessage;[Lch/odi/pam/PamResponse;)I"); if (pam_convid == NULL) goto error;
  ret = (*env)->CallIntMethod(env, pam, pam_convid, msg_ar, resp_ar);
  
  if (ret == PAM_SUCCESS) {
    //convert responses back
    *resp = calloc(num_msg, sizeof(struct pam_response));
    if (*resp == NULL) {
      printf("out of memory\n");
      goto error;
    }
    jfieldID resp_respID = (*env)->GetFieldID(env, resp_class, "resp", "Ljava/lang/String;"); if (resp_respID == NULL) goto error;
    jfieldID resp_retcodeID = (*env)->GetFieldID(env, resp_class, "resp_retcode", "I"); if (resp_retcodeID == NULL) goto error;

    for (i=0; i < num_msg; i++) {
      jobject r = (*env)->GetObjectArrayElement(env, resp_ar, i);
      if (r == NULL) continue;
      jstring s = (jstring) (*env)->GetObjectField(env, r, resp_respID);
      if (s == NULL) continue;
      // make a copy of the response message
      const char *tmp = (*env)->GetStringUTFChars(env, s, NULL);
      (*resp)[i].resp = x_strdup(tmp);
      (*resp)[i].resp_retcode = (*env)->GetIntField(env, r, resp_retcodeID);
      // clean up
      (*env)->ReleaseStringUTFChars(env, s, tmp);
    }
    // clean up PamResponse[]
    (*env)->DeleteGlobalRef(env, resp_ar);
  }
  
  error:
  if ((*env)->ExceptionOccurred(env) != NULL) {
    (*env)->ExceptionDescribe(env);    
  }

  return ret;
};

/*
 * preload the pam shared libs
 * attention, the JNI 1.4 version is used
 * requires Java 1.4 or higher
 */
JNIEXPORT jint JNICALL JNI_OnLoad (JavaVM * vm, void * reserved) {
  libpam = dlopen("libpam.so", RTLD_GLOBAL | RTLD_LAZY); 
  libpam_misc = dlopen("libpam_misc.so", RTLD_GLOBAL | RTLD_LAZY);
  return JNI_VERSION_1_4;
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM *vm, void *reserved) {
  dlclose(libpam);
  dlclose(libpam_misc);
}

JNIEXPORT jint JNICALL Java_ch_odi_pam_Pam_pam_1start
  (JNIEnv *env, jobject pam, jstring service_name, jstring user) {

  // store VM in pam_conv 
  struct conv_param_t *conv_param = calloc(1, sizeof(struct conv_param_t));
  
  (*env)->GetJavaVM(env, &((*conv_param).vm));
  (*conv_param).pam = (*env)->NewGlobalRef(env, pam); //do not store local refs
  struct pam_conv *conv = calloc(1, sizeof(struct pam_conv));
  (*conv).conv = &conversation;
  (*conv).appdata_ptr = conv_param;
  
  pam_handle_t *handle = NULL;
  const char *service = (*env)->GetStringUTFChars(env, service_name, NULL);
  const char *name = NULL;
  if (user != NULL) name = (*env)->GetStringUTFChars(env, user, NULL);  
  int ret = pam_start(service, name, conv, &handle); 
  (*env)->ReleaseStringUTFChars(env, service_name, service);
  (*env)->ReleaseStringUTFChars(env, user, name);
  free(conv);
  if (ret == PAM_SUCCESS) {
    jclass clazz = (*env)->GetObjectClass(env, pam);
    jfieldID pam_handleID = (*env)->GetFieldID(env, clazz, "pam_handle", "J");
    (*env)->SetLongField(env, pam, pam_handleID, (jlong) handle);
  }
  return ret; 
}

JNIEXPORT void JNICALL Java_ch_odi_pam_Pam_pam_1end
  (JNIEnv *env, jobject pam, jlong jhandle) {
  pam_handle_t *handle = (pam_handle_t*) jhandle;
  struct pam_conv *conv = NULL;
  pam_get_item(handle, PAM_CONV, (const void**) &conv); 
  /*
   * free the appdata_ptr
   * and the Pam.java object reference
   */
  if (conv != NULL) {
    struct conv_param_t *conv_param = (*conv).appdata_ptr;
    (*env)->DeleteGlobalRef(env, (*conv_param).pam);
    free((*conv).appdata_ptr);
    (*conv).appdata_ptr = NULL;
  }
  //shutdown PAM
  if (pam_end(handle, PAM_SUCCESS) != PAM_SUCCESS) {
    handle = NULL;
  }
}

JNIEXPORT jstring JNICALL Java_ch_odi_pam_Pam_pam_1get_1str_1item
  (JNIEnv *env, jobject pam, jlong jhandle, jint item) {
  pam_handle_t *handle = (pam_handle_t*) jhandle;
  char *str = NULL;
  int ret = pam_get_item(handle, item, (const void**) &str);
  if (ret != PAM_SUCCESS) return NULL;
  return (*env)->NewStringUTF(env, str);
}
  
JNIEXPORT jint JNICALL Java_ch_odi_pam_Pam_pam_1set_1str_1item
  (JNIEnv *env, jobject pam, jlong jhandle, jint item, jstring value) {
  pam_handle_t *handle = (pam_handle_t*) jhandle;
  const char *s = (*env)->GetStringUTFChars(env, value, NULL);
  jint ret = pam_set_item(handle, item, s);
  (*env)->ReleaseStringUTFChars(env, value, s);
  return ret;
}
  
  
JNIEXPORT jint JNICALL Java_ch_odi_pam_Pam_pam_1authenticate
  (JNIEnv *env, jobject pam, jlong jhandle, jint flags) {
  pam_handle_t *handle = (pam_handle_t*) jhandle;
  return pam_authenticate(handle, flags);
}

JNIEXPORT jstring JNICALL Java_ch_odi_pam_Pam_pam_1strerror
  (JNIEnv *env, jobject pam, jlong jhandle, jint errnum) {
  pam_handle_t *handle = (pam_handle_t*) jhandle;
  const char *message = pam_strerror(handle, errnum);
  return (*env)->NewStringUTF(env, message);
}

JNIEXPORT jint JNICALL Java_ch_odi_pam_Pam_pam_1acct_1mgmt
  (JNIEnv *env, jobject pam, jlong jhandle, jint flags) {
  pam_handle_t *handle = (pam_handle_t*) jhandle;
  pam_acct_mgmt(handle, flags);  
}

JNIEXPORT jint JNICALL Java_ch_odi_pam_Pam_pam_1setcred
  (JNIEnv *env, jobject pam, jlong jhandle, jint flags) {
  pam_handle_t *handle = (pam_handle_t*) jhandle;
  return pam_setcred(handle, flags);
}

JNIEXPORT jint JNICALL Java_ch_odi_pam_Pam_pam_1chauthtok
  (JNIEnv *env, jobject pam, jlong jhandle, jint flags) {
  pam_handle_t *handle = (pam_handle_t*) jhandle;
  return pam_chauthtok(handle, flags);
}

JNIEXPORT jint JNICALL Java_ch_odi_pam_Pam_pam_1open_1session
  (JNIEnv *env, jobject pam, jlong jhandle, jint flags) {
  pam_handle_t *handle = (pam_handle_t*) jhandle;
  return pam_open_session(handle, flags);
}

JNIEXPORT jint JNICALL Java_ch_odi_pam_Pam_pam_1close_1session
  (JNIEnv *env, jobject pam, jlong jhandle, jint flags) {
  pam_handle_t *handle = (pam_handle_t*) jhandle;
  return pam_close_session(handle, flags);
}
  