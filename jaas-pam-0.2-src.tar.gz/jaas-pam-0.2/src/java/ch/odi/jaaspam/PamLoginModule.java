package ch.odi.jaaspam;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.ChoiceCallback;
import javax.security.auth.callback.ConfirmationCallback;
import javax.security.auth.callback.LanguageCallback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.TextInputCallback;
import javax.security.auth.callback.TextOutputCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.AccountExpiredException;
import javax.security.auth.login.CredentialExpiredException;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;

import ch.odi.pam.Pam;
import ch.odi.pam.PamCallback;
import ch.odi.pam.PamConstants;
import ch.odi.pam.PamError;
import ch.odi.pam.PamMessage;
import ch.odi.pam.PamResponse;

/**
 * JAAS login module that defers the actual authentication
 * to PAM. This login module must set the PAM service name
 * in the JAAS config file. The service name is passed as
 * the value to the option named <code>service</code>.
 * <p>Sample configuration:</p>
 * <code>
 * pam-sample {
 *  ch.odi.jaaspam.PamLoginModule required service=login;
 * };
 * </code>
 *
 * @author Ortwin Gl�ck
 */
public class PamLoginModule implements LoginModule {
    private Pam pam;
    private CallbackHandler ch;
    private Subject subject;
    private String userPrompt;
    private String pamUsername;
    private boolean logged_in = false;
    private PamPrincipal principal = null;
    
    /**
     * 
     */
    public PamLoginModule() {
    }

    /**
     * Initializes PAM with the service name.
     * 
     * @param subject The subject to authenticate. Can be empty to make PAM ask for a username.
     */
    public void initialize(Subject subject, CallbackHandler callbackHandler,
            Map sharedState, Map options) {
        this.subject = subject;
        String serviceName = (String) options.get("service");
        if (serviceName == null) throw new IllegalArgumentException("service option not set in JAAS config for PamLoginModule");
        //TODO: examine subject principals for an existing PamPrincipal
        pam = new Pam(serviceName, null, new JaasPamCallback());
        this.ch = callbackHandler;
    }

    public boolean login() throws LoginException {
        if (ch == null) throw new LoginException("Error: no CallbackHandler available " +
                                     "to garner authentication information from the user");
        
        logged_in = false;
        this.userPrompt = pam.getItem(PamConstants.PAM_USER_PROMPT);
        if (this.userPrompt == null) {
            this.userPrompt = PamConstants.PAM_DEFAULT_PROMPT;
            pam.setItem(PamConstants.PAM_USER_PROMPT, this.userPrompt);
        }
        int status = pam.authenticate();
        String statusMsg = pam.getError(status);
        switch (status) {
            case PamConstants.PAM_USER_UNKNOWN:
            case PamConstants.PAM_AUTH_ERR:
                freePam();
                throw new FailedLoginException(statusMsg);
    
            case PamConstants.PAM_CRED_INSUFFICIENT:
                freePam();
                throw new CredentialsInsufficientException(statusMsg);
    
            case PamConstants.PAM_AUTHINFO_UNAVAIL:
                freePam();
                throw new AuthInfoUnavailableException(statusMsg);
    
            case PamConstants.PAM_MAXTRIES:
                freePam();
                throw new MaxRetriesException(statusMsg);
    
            case PamConstants.PAM_ABORT:
                freePam();
                throw new PamModuleLoadingException(statusMsg);
    
            case PamConstants.PAM_SUCCESS:
                /* do nothing and continue after switch */
                break;
    
            default:
                freePam();
                throw new LoginException(statusMsg + " (pam_authenticate)");
        }
        
        status = pam.accountManagement();
        statusMsg = pam.getError(status);
        switch (status) {
            case PamConstants.PAM_AUTHTOK_EXPIRED:
                freePam();
                throw new CredentialExpiredException(statusMsg);
            
            case PamConstants.PAM_ACCT_EXPIRED:
                freePam();
                throw new AccountExpiredException(statusMsg);
            
            case PamConstants.PAM_AUTH_ERR:
                freePam();
                throw new LoginException(statusMsg);
            
            case PamConstants.PAM_PERM_DENIED:
                freePam();
                throw new PermissionDeniedException(statusMsg);
            
            case PamConstants.PAM_USER_UNKNOWN:
                freePam();
                return false;
            
            case PamConstants.PAM_AUTHINFO_UNAVAIL:
                /* seems account management is not supported for this service */
                break;
            
            case PamConstants.PAM_SUCCESS:
                /* do nothing and continue after switch */
                break;
            
            //default is to accept login
        }
        
        logged_in = true; 
        return true;
    }

    public boolean commit() throws LoginException {
        freePam();
        if (!logged_in) return false;
        principal = new PamPrincipal(pamUsername);
        Set principals = subject.getPrincipals();
        if (!principals.contains(principal)) principals.add(principal);
        
        logged_in = false;
        pamUsername = null;
        return true;
    }

    public boolean abort() throws LoginException {
        reset();
        if (!logged_in) return false;
        if (principal != null) {
            logout();
        } else {
            freePam();
            pamUsername = null;
        }
        return false;
    }

    public boolean logout() throws LoginException {
        if (subject.isReadOnly()) return false;
        Set principals = subject.getPrincipals();
        if (!principals.contains(principal)) return false;
        principals.remove(principal);
        principal = null;
        freePam();
        pamUsername = null;
        return true;
    }
    
    private void reset() {
            this.principal = null;
            this.pamUsername = null;
            this.logged_in = false;
    }
    
    private void freePam() {
        if (pam != null) {
            pam.end();
            pam = null;
        }
    }

    private class JaasPamCallback implements PamCallback {

        public int handle(PamMessage[] messages, PamResponse[] responses) {
            Callback[] callbacks = toCallbacks(messages);
            try {
                ch.handle(callbacks);
                answer(callbacks, responses);
                return PamConstants.PAM_SUCCESS;
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedCallbackException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return PamConstants.PAM_CONV_ERR;
        }
        
        /**
         * @param callbacks
         * @param responses
         */
        private void answer(Callback[] callbacks, PamResponse[] responses) {
            String text = null;
            for (int i = 0; i < callbacks.length; i++) {
                PamResponse response = null; 
                Callback callback = callbacks[i];
                if (callback instanceof NameCallback) {
                    pamUsername = ((NameCallback) callback).getName();
                    response = new PamResponse(pamUsername);
                } else if (callback instanceof TextInputCallback) {
                    text = ((TextInputCallback) callback).getText();
                    response = new PamResponse(text);
                } else if (callback instanceof PasswordCallback) {
                    response = new PamResponse(String.valueOf(((PasswordCallback) callback).getPassword()));
                } else if (callback instanceof TextOutputCallback) {
                    response = new PamResponse("");
                } else if (callback instanceof LanguageCallback) {
                    response = new PamResponse(((LanguageCallback) callback).getLocale().toString());
                } else if (callback instanceof ConfirmationCallback) {
                    ConfirmationCallback cb = (ConfirmationCallback) callback;
                    String option = cb.getOptions()[cb.getSelectedIndex()];
                    response = new PamResponse(option);
                } else if (callback instanceof ChoiceCallback) {
                    // there is no PAM standard for that
                    throw new PamError("Unsupported: ChoiceCallback. Please implement a custom login module");
                }
                responses[i] = response;
            }
            if (pamUsername == null) pamUsername = text; //guess this is the username
        }

        private Callback[] toCallbacks(PamMessage[] messages) {
            Callback[] callbacks = new Callback[messages.length];
            for (int i = 0; i < messages.length; i++) {
                PamMessage message = messages[i];
                Callback callback = null;
                switch (message.getMsg_style()) {
                    case PamConstants.PAM_PROMPT_ECHO_ON:
                        if (userPrompt.equals(message.getMsg())) {
                            callback = new NameCallback(message.getMsg());
                        } else {
                            callback = new TextInputCallback(message.getMsg());
                        }
                        break;
                    
                    case PamConstants.PAM_PROMPT_ECHO_OFF:
                        //prompts without echo are probably passwords
                        callback = new PasswordCallback(message.getMsg(), false);
                        break;
                    
                    case PamConstants.PAM_TEXT_INFO:
                        callback = new TextOutputCallback(TextOutputCallback.INFORMATION, message.getMsg());
                        break;
                    
                    case PamConstants.PAM_ERROR_MSG:
                        callback = new TextOutputCallback(TextOutputCallback.ERROR, message.getMsg());
                        break;
                    
                    default:
                        throw new PamError("message style "+ message.getMsg_style() +" unknown");
                }
                callbacks[i] = callback;
            }
            return callbacks;
        }
    }
}
