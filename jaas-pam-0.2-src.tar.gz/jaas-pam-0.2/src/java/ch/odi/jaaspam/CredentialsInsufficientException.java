package ch.odi.jaaspam;

import javax.security.auth.login.LoginException;

/**
 * The credentials provided by the application were not sufficient to authenticate the user.
 *
 * @author Ortwin Gl�ck
 */
public class CredentialsInsufficientException extends LoginException {

    /**
     * 
     */
    public CredentialsInsufficientException() {
        super();
    }

    /**
     * @param msg
     */
    public CredentialsInsufficientException(String msg) {
        super(msg);
    }

}
