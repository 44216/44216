package ch.odi.jaaspam;

import javax.security.auth.login.LoginException;

/**
 * One or more of the authentication modules has reached its limit of tries authenticating
 * the user. Do not try again.
 *
 * @author Ortwin Gl�ck
 */
public class MaxRetriesException extends LoginException {

    /**
     * 
     */
    public MaxRetriesException() {
        super();
    }

    /**
     * @param msg
     */
    public MaxRetriesException(String msg) {
        super(msg);
    }

}
