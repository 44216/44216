package ch.odi.jaaspam;

import javax.security.auth.login.LoginException;

/**
 * The user is not permitted to gain access at this time.
 *
 * @author Ortwin Gl�ck
 */
public class PermissionDeniedException extends LoginException {

    /**
     * 
     */
    public PermissionDeniedException() {
        super();
    }

    /**
     * @param msg
     */
    public PermissionDeniedException(String msg) {
        super(msg);
    }

}
