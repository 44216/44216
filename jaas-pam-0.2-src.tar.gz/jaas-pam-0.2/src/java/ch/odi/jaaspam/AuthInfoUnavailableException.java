package ch.odi.jaaspam;

import javax.security.auth.login.LoginException;

/**
 * Signals failure to access the authentication information. This may be a temporary problem
 * or a misconfiguration. 
 *
 * @author Ortwin Gl�ck
 */
public class AuthInfoUnavailableException extends LoginException {

    /**
     * 
     */
    public AuthInfoUnavailableException() {
        super();
    }

    /**
     * @param msg
     */
    public AuthInfoUnavailableException(String msg) {
        super(msg);
    }

}
