package ch.odi.jaaspam;

import javax.security.auth.login.LoginException;

/**
 * A PAM module failed to load. 
 *
 * @author Ortwin Gl�ck
 */
public class PamModuleLoadingException extends LoginException {

    /**
     * 
     */
    public PamModuleLoadingException() {
        super();
    }

    /**
     * @param msg
     */
    public PamModuleLoadingException(String msg) {
        super(msg);
    }

}
