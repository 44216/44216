package ch.odi.jaaspam;

import java.security.Principal;

/**
 * An implementation of Principal suitable for PAM.
 * A PAM principal is identified by a username.
 *
 * @author Ortwin Gl�ck
 */
public class PamPrincipal implements Principal {
    private String name;
    
    public PamPrincipal(String name) {
        if (name == null) {
            throw new IllegalArgumentException("name must not be null");
        }
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
    public boolean equals(Object o) {
        if (o == null) return false;
        if (this == o)  return true;
        if (!(o instanceof PamPrincipal)) return false;
        PamPrincipal that = (PamPrincipal) o;
        return this.name.equals(that.name);
    }
    
    public int hashCode() {
        return name.hashCode();
    }

}