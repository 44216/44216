package ch.odi.pam;

/**
 * Callback interface for Pam. Pam will query the application for credentials through
 * this interface.
 *
 * @author Ortwin Gl�ck
 */
public interface PamCallback {
    /**
     * Implementing methods should examine the messages and create appropriate responses.
     * 
     * @param messages The messages.
     * @param responses An empty array of the same size as messages.
     * @return PAM_SUCCESS is the expected return value of this function. However, should an error
     *  occur the application should not set the responses but simply return PAM_CONV_ERR.
     */
    int handle(PamMessage[] messages, PamResponse[] responses);
}
