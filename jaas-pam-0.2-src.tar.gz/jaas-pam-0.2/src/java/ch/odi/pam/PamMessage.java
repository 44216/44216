package ch.odi.pam;

/**
 * A message to show to the user. Instances of this class are immutable.
 *
 * @author Ortwin Gl�ck
 */
public class PamMessage {
    private int msg_style;
    private String msg;
    
    public PamMessage(int msg_style, String msg) {
        this.msg_style = msg_style;
        this.msg = msg;
    }

    /**
     * Gets the message string.
     * @return the message
     */
    public String getMsg() {
        return msg;
    }
    
    /**
     * Determines what to do with the message.
     * 
     * @return one of the constants
     * PAM_PROMPT_ECHO_OFF
     *  Obtain a string without echoing any text
     *  
     * PAM_PROMPT_ECHO_ON
     *  Obtain a string whilst echoing text
     *  
     * PAM_ERROR_MSG
     *  Display an error
     *  
     * PAM_TEXT_INFO
     *  Display some text. 
     */
    public int getMsg_style() {
        return msg_style;
    }
}
