package ch.odi.pam;

/**
 * A response to a message that is sent back to Pam. Instances of this class are immutable.
 *
 * @author Ortwin Gl�ck
 */
public class PamResponse {
    // those are read by the native code. Do not remove!
    private String resp;
    private int resp_retcode;
    
    /**
     * Creates a new PamResponse with 0 as the retcode.
     * 
     * @param resp The response
     */
    public PamResponse(String resp) {
        this(resp, 0);
    }
    
    /**
     * Create a new PamResponse.
     * 
     * @param resp The response
     * @param retcode Currently, there are no definitions for retcode values; the normal value is 0.
     */
    public PamResponse(String resp, int retcode) {
        this.resp = resp;
        this.resp_retcode = retcode;
    }
}
