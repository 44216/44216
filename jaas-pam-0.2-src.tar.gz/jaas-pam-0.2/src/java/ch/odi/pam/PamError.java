package ch.odi.pam;

/**
 * Super class of all errors from Pam.
 *
 * @author Ortwin Gl�ck
 */
public class PamError extends Error {

    /**
     * 
     */
    public PamError() {
        super();
    }

    /**
     * @param message
     */
    public PamError(String message) {
        super(message);
    }

    /**
     * @param message
     * @param cause
     */
    public PamError(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param cause
     */
    public PamError(Throwable cause) {
        super(cause);
    }

}
