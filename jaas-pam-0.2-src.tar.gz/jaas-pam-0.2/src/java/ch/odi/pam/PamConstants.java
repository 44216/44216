package ch.odi.pam;

/**
 * PAM Constants.
 * Adapted from /usr/include/security/_pam_types.h by Theodore Ts'o and Andrew G. Morgan.
 * Original C Header file is licensed under the GPL.
 *
 * @author Ortwin Gl�ck
 */
public class PamConstants {
    public static final int PAM_SUCCESS = 0;
    public static final int PAM_OPEN_ERR = 1;
    public static final int PAM_SYMBOL_ERR = 2;
    public static final int PAM_SERVICE_ERR = 3;
    public static final int PAM_SYSTEM_ERR = 4;
    public static final int PAM_BUF_ERR = 5;
    public static final int PAM_PERM_DENIED = 6;
    public static final int PAM_AUTH_ERR = 7;
    public static final int PAM_CRED_INSUFFICIENT = 8;
    public static final int PAM_AUTHINFO_UNAVAIL = 9;
    public static final int PAM_USER_UNKNOWN = 10;
    public static final int PAM_MAXTRIES = 11;
    public static final int PAM_NEW_AUTHTOK_REQD = 12;
    public static final int PAM_ACCT_EXPIRED = 13;
    public static final int PAM_SESSION_ERR = 14;
    public static final int PAM_CRED_UNAVAIL = 15;
    public static final int PAM_CRED_EXPIRED = 16;
    public static final int PAM_CRED_ERR = 17;
    public static final int PAM_NO_MODULE_DATA = 18;
    public static final int PAM_CONV_ERR = 19;
    public static final int PAM_AUTHTOK_ERR = 20;
    public static final int PAM_AUTHTOK_RECOVER_ERR = 21;
    public static final int PAM_AUTHTOK_LOCK_BUSY = 22;
    public static final int PAM_AUTHTOK_DISABLE_AGING = 23;
    public static final int PAM_TRY_AGAIN = 24;
    public static final int PAM_IGNORE = 25;
    public static final int PAM_ABORT = 26;
    public static final int PAM_AUTHTOK_EXPIRED = 27;
    public static final int PAM_MODULE_UNKNOWN = 28;
    public static final int PAM_BAD_ITEM = 29;
    public static final int PAM_CONV_AGAIN = 30;
    public static final int PAM_INCOMPLETE = 31;
    
    public static final int PAM_SILENT = 0x8000;
    public static final int PAM_DISALLOW_NULL_AUTHTOK = 0x0001;
    public static final int PAM_ESTABLISH_CRED = 0x0002;
    public static final int PAM_DELETE_CRED = 0x0004;
    public static final int PAM_REINITIALIZE_CRED = 0x0008;
    public static final int PAM_REFRESH_CRED = 0x0010;
    public static final int PAM_CHANGE_EXPIRED_AUTHTOK = 0x0020;
    
    public static final int PAM_SERVICE = 1;
    public static final int PAM_USER = 2;
    public static final int PAM_TTY = 3;
    public static final int PAM_RHOST = 4;
    public static final int PAM_CONV = 5;
    public static final int PAM_RUSER = 8;
    public static final int PAM_USER_PROMPT = 9;
    public static final int PAM_FAIL_DELAY = 10;
    
    public static final long PAM_DATA_SILENT = 0x4000000L;
    
    public static final int PAM_PROMPT_ECHO_OFF = 1;
    public static final int PAM_PROMPT_ECHO_ON = 2;
    public static final int PAM_ERROR_MSG = 3;
    public static final int PAM_TEXT_INFO = 4;
    public static final int PAM_RADIO_TYPE = 5;
    public static final int PAM_BINARY_PROMPT = 7;
    public static final int PAM_MAX_NUM_MSG = 32;
    public static final int PAM_MAX_MSG_SIZE = 512;
    public static final int PAM_MAX_RESP_SIZE = 512;
    
    // taken from libpam/pam_private.h
    public static final String PAM_DEFAULT_PROMPT = "login: ";
}
