package ch.odi.jaaspam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.Principal;
import java.util.Iterator;
import java.util.Set;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.TextInputCallback;
import javax.security.auth.callback.TextOutputCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

/**
 * Run as:
 * LD_LIBRARY_PATH=./target/native java -cp target/classes -Djava.security.auth.login.config=src/conf/sample_jaas.config ch.odi.jaaspam.TestJaas
 *
 * @author Ortwin Gl�ck
 */
public class TestJaas {

    /**
     * 
     */
    public TestJaas() {
        try {
            LoginContext lc = new LoginContext("pam-sample", new MyCallbackHandler());
            lc.login();
            System.out.print("Authenticated principals: ");
            Subject subject = lc.getSubject();
            Set principals = subject.getPrincipals();
            Iterator i = principals.iterator();
            while (i.hasNext()) {
                Principal p = (Principal) i.next();
                System.out.print(p.getName());
                System.out.print(" ");
            }
            System.out.println("");
        } catch (LoginException e) {
            System.out.println("Authentication failed");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new TestJaas();
    }
    
    private class MyCallbackHandler implements CallbackHandler {
        private BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
        
        public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
             for (int i = 0; i < callbacks.length; i++) {
                if (callbacks[i] instanceof TextOutputCallback) {
                    // display the message according to the specified type
                    TextOutputCallback toc = (TextOutputCallback)callbacks[i];
                    switch (toc.getMessageType()) {
                    case TextOutputCallback.INFORMATION:
                        System.out.println(toc.getMessage());
                        break;
                    case TextOutputCallback.ERROR:
                        System.out.println("ERROR: " + toc.getMessage());
                        break;
                    case TextOutputCallback.WARNING:
                        System.out.println("WARNING: " + toc.getMessage());
                        break;
                    default:
                        throw new IOException("Unsupported message type: " +
                                toc.getMessageType());
                    }
                } else if (callbacks[i] instanceof TextInputCallback) { 
                    TextInputCallback tic = (TextInputCallback) callbacks[i];
                    System.err.print(tic.getPrompt());
                    System.err.flush();
                    tic.setText(read());
                } else if (callbacks[i] instanceof NameCallback) {
                    // prompt the user for a username
                    NameCallback nc = (NameCallback)callbacks[i];
              
                    // ignore the provided defaultName
                    System.err.print(nc.getPrompt());
                    System.err.flush();
                    nc.setName(read());
                } else if (callbacks[i] instanceof PasswordCallback) {
                    // prompt the user for sensitive information
                    PasswordCallback pc = (PasswordCallback)callbacks[i];
                    System.err.print(pc.getPrompt());
                    System.err.flush();
                    pc.setPassword(read().toCharArray());
                } else {
                    throw new UnsupportedCallbackException
                        (callbacks[i], "Unrecognized Callback");
                }
             }
        }

        private String read() throws IOException {
            String line = r.readLine();
            return line;
        }
        
    }
}
