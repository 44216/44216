package ch.odi.jaaspam;

import java.io.IOException;
import java.security.Principal;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

import javax.security.auth.Subject;
import javax.security.auth.callback.*;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

/**
 * Eclipse:
 * -Djava.library.path=target/native -Djava.security.auth.login.config=src/conf/jaas-pam-test.config
 * Console:
 * LD_LIBRARY_PATH=target/native java -cp target/classes -Djava.security.auth.login.config=src/conf/jaas-pam-test.config ch.odi.jaaspam.TestJaas
 *
 * @author Carsten Weisse
 */
public class StressJaasPam implements Runnable {

    
    private static final int MAX_LOGINS = 3;
    private static final int DEFAULT_THREADS = 1000;
    private static final int MAX_CONCURRENT_THREADS = 100;
    
    private String user;
    private String password;
    /**
     * 
     */
    public StressJaasPam(String user, String password) {
        this.user = user;
        this.password = password;
    }
    
    public String getUser() {
        return user;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void run() {
        String thread = Thread.currentThread().getName();
        boolean retry = true;
        for (int n = 0; (retry && n < MAX_LOGINS); n++) {
            try {
                LoginContext lc = new LoginContext("jaas-pam-test", new MyCallbackHandler());
                lc.login();
                Subject subject = lc.getSubject();
                Set principals = subject.getPrincipals();
                Iterator i = principals.iterator();

                String login = "";
                while (i.hasNext()) {
                    Principal p = (Principal) i.next();
                    login = p.getName();
                }
                // successful
                if (n == 0) {
                    System.err.println(thread + ": " + login + " successful");
                } else {
                    System.err.println(thread + ": " + login +" successful after " + n );
                }
                retry = false;
            } catch (LoginException e) {
                //System.out.println(thread + " " + e);
                if (n == (MAX_LOGINS - 1))
                    System.err.println(thread + " failed.");
                try {
                    Thread.sleep((new Random()).nextInt(500) + 500);
                } catch (InterruptedException ie) {
                    // do nothing
                }
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("*** Jaas-Pam Stress Test ***");
        int count = DEFAULT_THREADS;
        if (args != null && args.length == 1) {
            count = Integer.parseInt(args[0]);
        }
        System.out.println("*** Run " + count + " login  threads ***");
        
        String user;
        String pwd;
        Thread tx = null;
        for (int n = 0; n < count; n++) {
            /*
             * create 4 test users for your system
             * login password
             * ---------------------
             * test0 test0
             * test1 test1
             * test2 test2
             * test3 test3
             */
            user = pwd = "test" + (n % 4);
            // create wrong passwords 
            if ((n % 4) == 1) pwd += "*";
            tx = new Thread(new StressJaasPam(user, pwd), "T" + n);
            tx.start();
            // call gc after 1000 logins
            if ((n % 1000) == 0) System.gc();
            // wait a little bit after 100 login threads
            if ((n % MAX_CONCURRENT_THREADS) == MAX_CONCURRENT_THREADS - 1) {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ie) {
                    // do nothing
                }
            }
        }
        // wait until the last thread is finished
        try {
            tx.join();
        } catch (InterruptedException e) {
        }
        System.gc();
        System.out.println();
        System.out.println("*** end ***");
    }
    
    private class MyCallbackHandler implements CallbackHandler {
        public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {

            for (int i = 0; i < callbacks.length; i++) {

                if (callbacks[i] instanceof TextOutputCallback) {
                    // display the message according to the specified type
                    TextOutputCallback toc = (TextOutputCallback)callbacks[i];
                    switch (toc.getMessageType()) {
                    case TextOutputCallback.INFORMATION:
                        //System.out.println(toc.getMessage());
                        break;
                    case TextOutputCallback.ERROR:
                        System.out.println("ERROR: " + toc.getMessage());
                        break;
                    case TextOutputCallback.WARNING:
                        System.out.println("WARNING: " + toc.getMessage());
                        break;
                    default:
                        throw new IOException("Unsupported message type: " +
                                toc.getMessageType());
                    }
                } else if (callbacks[i] instanceof TextInputCallback) { 
                    TextInputCallback tic = (TextInputCallback) callbacks[i];
                    // set login prompt
                    tic.setText("login:");
                } else if (callbacks[i] instanceof NameCallback) {
                    // set username
                    NameCallback nc = (NameCallback)callbacks[i];
                    nc.setName(StressJaasPam.this.getUser());
                } else if (callbacks[i] instanceof PasswordCallback) {
                    // set password
                    PasswordCallback pc = (PasswordCallback)callbacks[i];
                    pc.setPassword(StressJaasPam.this.getPassword().toCharArray());
                } else {
                    throw new UnsupportedCallbackException
                        (callbacks[i], "Unrecognized Callback");
                }
             }
        }
    }
}
