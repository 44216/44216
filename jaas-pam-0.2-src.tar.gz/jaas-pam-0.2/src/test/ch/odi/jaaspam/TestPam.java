package ch.odi.jaaspam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import ch.odi.pam.Pam;
import ch.odi.pam.PamCallback;
import ch.odi.pam.PamConstants;
import ch.odi.pam.PamMessage;
import ch.odi.pam.PamResponse;

/**
 * On Linux call this as:
 * LD_LIBRARY_PATH=./target/native java -cp target/classes ch.odi.jaaspam.TestPam
 *
 * @author Ortwin Gl�ck
 */
public class TestPam {

    /**
     * 
     */
    public TestPam() {
        Pam pam = new Pam("login", null, new MyPamCallback());
        pam.setItem(PamConstants.PAM_USER_PROMPT, "Enter username");
        System.out.println("User: "+ pam.getItem(PamConstants.PAM_USER));
        System.out.println("Service: "+ pam.getItem(PamConstants.PAM_SERVICE));
        int status = pam.authenticate();
        if (status == PamConstants.PAM_SUCCESS) { 
            status = pam.accountManagement();
            if ((status == PamConstants.PAM_SUCCESS) 
                    || (status == PamConstants.PAM_AUTHINFO_UNAVAIL)) {
                System.out.println("User successfully authenticated");
            } else {
                System.out.println("Account has insufficient rights: "+ pam.getError(status));
            }
        } else {
            System.out.println("Authentication failed: "+ pam.getError(status));
        }
        pam.end();
    }

    public static void main(String[] args) {
        new TestPam();
    }
    
    private class MyPamCallback implements PamCallback {

        public int handle(PamMessage[] messages, PamResponse[] responses) {
            BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
            for (int i=0; i<messages.length; i++) {
                System.out.println(messages[i].getMsg());
                try {
                    responses[i] = new PamResponse(r.readLine());
                } catch (IOException e) {
                    return PamConstants.PAM_CONV_ERR;
                }
            }
            return PamConstants.PAM_SUCCESS;
        }
        
    }
}
